package jack

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func trimLine(line string) string {
	commentIdx := strings.Index(line, "//")
	if commentIdx >= 0 {
		line = line[0:commentIdx]
	}
	line = strings.TrimSpace(line)
	return line
}

func ForLinesInFile(filename string, processLine func(line string, lineno int) error) {
	lineno := 0
	f, err := os.Open(filename)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		lineno++
		line := scanner.Text()
		line = trimLine(line)
		err = processLine(line, lineno)
		if err != nil {
			fmt.Printf("line %d, %v\n", lineno, err)
			os.Exit(1)
		}
	}
}
