package parser

import (
	"fmt"
	"io"
	"strconv"
)

var labelsn = 1000

func writeCode(cmd command) {
	switch cmd.ctype {
	case C_ARITHMETIC:
		writeArithmetic(cmd)
	case C_PUSH, C_POP:
		writePushOrPop(cmd)
	}
}

func writePushOrPop(cmd command) {
	switch cmd.arg1 {
	case "constant":
		write("@%s", cmd.arg2)
		write("D=A")
		pushDRegister()
		return
	case "local", "argument", "this", "that":
		write("@%s", cmd.arg2)
		write("D=A") // store offset in D
		if cmd.arg1 == "local" {
			write("@LCL")
		} else if cmd.arg1 == "argument" {
			write("@ARG")
		} else if cmd.arg1 == "this" {
			write("@THIS")
		} else if cmd.arg1 == "that" {
			write("@THAT")
		}
		if cmd.ctype == C_POP {
			write("D=D+M") // D holds address of cell we want to pop into
			write("@R13")
			write("M=D") // R13 holds address we want to pop into
			popIntoDRegister()
			write("@R13")
			write("A=M")
			write("M=D")
		} else {
			write("A=D+M") // A holds address of cell we want to push from
			write("D=M")   // D holds value we want to push
			pushDRegister()
		}
	case "static", "temp", "pointer":
		offset, err := strconv.Atoi(cmd.arg2)
		if err != nil {
			panic(err)
		}
		if cmd.arg1 == "static" {
			offset += 16
		} else if cmd.arg1 == "temp" {
			offset += 5
		} else if cmd.arg1 == "pointer" {
			offset += 3
		}
		// offset is the address of the relevant cell
		if cmd.ctype == C_POP {
			popIntoDRegister()
			write("@%d", offset)
			write("M=D")
		} else {
			write("@%d", offset)
			write("D=M")
			pushDRegister()
		}
	}
	if cmd.ctype == C_PUSH {
	} else {
	}
}

func writeArithmetic(cmd command) {
	// unary functions leave SP unchanged
	if cmd.command == "not" || cmd.command == "neg" {
		write("@SP")
		write("A=M-1") // A is address of argument
		write("D=M")   // D is argument
		if cmd.command == "not" {
			write("M=!M")
		} else {
			write("M=-M")
		}
		return
	}
	popIntoDRegister()
	// store in R13
	write("@R13")
	write("M=D")
	popIntoDRegister()

	write("@R13") // M is second argument
	switch cmd.command {
	case "add":
		write("D=D+M")
	case "sub":
		write("D=D-M")
	case "and":
		write("D=D&M")
	case "or":
		write("D=D|M")
	case "eq", "gt", "lt":
		falseLabel := newLabel()
		trueLabel := newLabel()
		write("D=D-M")
		write("@%s", trueLabel)
		switch cmd.command {
		case "eq":
			write("D;JEQ")
		case "gt":
			write("D;JGT")
		case "lt":
			write("D;JLT")
		}
		write("D=0")
		write("@%s", falseLabel)
		write("0;JMP")
		write("(%s)", trueLabel)
		write("D=-1")
		write("(%s)", falseLabel)
	}
	pushDRegister()
}

func newLabel() string {
	labelsn++
	return fmt.Sprintf("L%d", labelsn)
}

func write(format string, a ...interface{}) {
	outString := fmt.Sprintf(format, a...) + "\n"
	io.WriteString(asmFile, outString)
}

func popIntoDRegister() {
	write("@SP")    // A=2, so M will be RAM[2]
	write("AM=M-1") // decrement value in RAM[2] and store it in RAM[2] and A register
	// now A register is address of value to be popped
	write("D=M") // so now the value at that address is pulled into D
}

func pushDRegister() {
	write("@SP")   // A=2, so M will be RAM[2]
	write("A=M")   // A is RAM[2], which is address where value will be pushed
	write("M=D")   // put value of D into RAM[A]
	write("@SP")   // A=2 again, so M is RAM[2]
	write("M=M+1") // increment value in RAM[2] and overwrite it
}
