package parser

import (
	"fmt"
	"io"
	"jack"
	"strings"
)

const (
	C_UNRECOGNIZED_COMMAND = iota
	C_ARITHMETIC           = iota
	C_PUSH                 = iota
	C_POP                  = iota
	C_LABEL                = iota
	C_GOTO                 = iota
	C_IF                   = iota
	C_FUNCTION             = iota
	C_RETURN               = iota
	C_CALL                 = iota
)

type command struct {
	ctype   int
	command string
	arg1    string
	arg2    string
}

var asmFile io.Writer

func ParseFiles(filenames []string, output io.Writer) {
	asmFile = output
	for _, filename := range filenames {
		parseFile(filename)
	}
}

func parseFile(filename string) {
	fmt.Printf("parseFile called with filename:%s\n", filename)
	fmt.Printf("asmfile:%v\n", asmFile)
	jack.ForLinesInFile(filename, processLine)
}

func commandType(line string) (cmd command, err error) {
	var command, rest string
	command, rest = nextWord(line)
	command = strings.ToLower(command)
	cmd.command = command
	switch command {
	case "add", "sub", "neg", "eq", "gt", "lt", "and", "or", "not":
		cmd.ctype = C_ARITHMETIC
		return
	case "push", "pop":
		if command == "pop" {
			cmd.ctype = C_POP
		} else {
			cmd.ctype = C_PUSH
		}
	default:
		err = fmt.Errorf("unrecognized command")
		return
	}
	cmd.arg1, rest = nextWord(rest)
	cmd.arg2, rest = nextWord(rest)
	if len(rest) > 0 {
		err = fmt.Errorf("too many arguments")
	}
	return
}

func nextWord(restOfLine string) (word, rest string) {
	restOfLine = strings.TrimSpace(restOfLine)
	if len(restOfLine) == 0 {
		return
	}
	wsIdx := strings.IndexAny(restOfLine, " \t")
	if wsIdx < 0 {
		word = restOfLine
		return
	}
	word = restOfLine[0:wsIdx]
	rest = strings.TrimSpace(restOfLine[wsIdx+1:])
	return
}

func argMustBeNumber(arg string) error {
	nonDigits := strings.Trim(arg, "0123456789")
	if len(nonDigits) > 0 {
		return fmt.Errorf("must be a non-negative decimal number")
	}
	return nil
}

func vetCommand(cmd command) error {
	switch cmd.ctype {
	case C_ARITHMETIC:
		if len(cmd.arg1) != 0 {
			return fmt.Errorf("too many arguments for command %s", cmd.command)
		}
	case C_PUSH, C_POP:
		switch cmd.arg1 {
		case "argument", "local", "static", "constant", "this", "that", "pointer", "temp":
			// segment is good
		default:
			return fmt.Errorf("first argument of command %s must name a valid segment", cmd.command)
		}
		if cmd.ctype == C_POP && cmd.arg1 == "constant" {
			return fmt.Errorf("cannot pop into read-only 'constant' segment")
		}
		err := argMustBeNumber(cmd.arg2)
		if err != nil {
			return fmt.Errorf("second argument of %s %v", cmd.command, err)
		}
	}
	return nil
}

func processLine(line string, lineno int) error {
	fmt.Printf("processing line %d:%s\n", lineno, line)
	if line == "" {
		return nil
	}
	cmd, err := commandType(line)
	if err != nil {
		return fmt.Errorf("ERROR line %d, error:%v\n", lineno, err)
	}
	fmt.Printf("line %d: cmd:%s, arg1:%s, arg2:%s\n", lineno, cmd.command, cmd.arg1, cmd.arg2)
	err = vetCommand(cmd)
	if err != nil {
		return err
	}
	writeCode(cmd)
	return nil
}
